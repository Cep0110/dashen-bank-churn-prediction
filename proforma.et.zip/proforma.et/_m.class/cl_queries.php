<?php
require_once 'db_config.php';
class CL_QUERIES
{
	private $conn;
	
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}

	function register_seeker($seeker_name, $first_name, $last_name, $email, $phone, $password)
	{
		try
		{
			$seeker_id = md5(uniqid(mt_rand(),true));
			$stmt = $this->conn->prepare("INSERT INTO tbl_service_seeker (seeker_id,seeker_name) VALUES (:seeker_id, :seeker_name);");
			$stmt->bindparam(":seeker_id",$seeker_id);
			$stmt->bindparam(":seeker_name",$seeker_name);
			$stmt->execute();

			$manager_id = md5(uniqid(mt_rand(),true));
			$stmt = $this->conn->prepare("INSERT INTO tbl_seeker_manager (manager_id, first_name, last_name, email, phone, seeker) VALUES (:manager_id, :first_name, :last_name, :email, :phone, :seeker);");
			$stmt->bindparam(":manager_id",$manager_id);
			$stmt->bindparam(":first_name",$first_name);
			$stmt->bindparam(":last_name",$last_name);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":seeker",$seeker_id);
			$stmt->execute();

			$stmt = $this->conn->prepare("INSERT INTO tbl_seeker_address (seeker_id) VALUES (:seeker_id);");
			$stmt->bindparam(":seeker_id",$seeker_id);
			$stmt->execute();

			$sha_password = hash("sha512",$password);
			$password = password_hash($sha_password, PASSWORD_DEFAULT);
			$role = "manager";
			$stmt = $this->conn->prepare("INSERT INTO tbl_user (username, email, password, role, user_information_id) VALUES (:username, :email, :password, :role, :user_information_id);");
			$stmt->bindparam(":username",$first_name);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":password",$password);
			$stmt->bindparam(":role",$role);
			$stmt->bindparam(":user_information_id",$manager_id);
			$stmt->execute();

			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function create_proforma($proforma_id,$proforma_name, $category, $organization)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO tbl_proforma (proforma_id, proforma_name, category, organization) VALUES (:proforma_id, :proforma_name, :category, :organization);");
			$stmt->bindparam(":proforma_id",$proforma_id);
			$stmt->bindparam(":proforma_name",$proforma_name);
			$stmt->bindparam(":category",$category);
			$stmt->bindparam(":organization",$organization);
			$stmt->execute();
			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function register_pa($email,$password,$pa_id)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO tbl_provider_admin (pa_id,email) VALUES (:pa_id,:email);");
			$stmt->bindparam(":pa_id",$pa_id);
			$stmt->bindparam(":email",$email);
			$stmt->execute();


			$sha_password = hash("sha512",$password);
			$password = password_hash($sha_password, PASSWORD_DEFAULT);
			$role = "p_admin";
			if (preg_match("/^[^@]+/", $email, $matches)) {
		        $username = ucwords(str_replace(['.', '_'], ' ', $matches[0]));
		    }
		    else
		    {
		    	$username = "";
		    }
			$stmt1 = $this->conn->prepare("INSERT INTO tbl_user (username, email, password, role, user_information_id) VALUES (:username, :email, :password, :role, :user_information_id);");
			$stmt1->bindparam(":username",$username);
			$stmt1->bindparam(":email",$email);
			$stmt1->bindparam(":password",$password);
			$stmt1->bindparam(":role",$role);
			$stmt1->bindparam(":user_information_id",$pa_id);
			$stmt1->execute();


			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function register_pa_with_Google($givenName,$FamilyName,$email,$pa_id,$profile_picture)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO tbl_provider_admin (pa_id,email,first_name,last_name,profile_picture) VALUES (:pa_id,:email,:first_name,:last_name,:profile_picture);");
			$stmt->bindparam(":pa_id",$pa_id);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":first_name",$givenName);
			$stmt->bindparam(":last_name",$FamilyName);
			$stmt->bindparam(":profile_picture",$profile_picture);
			$stmt->execute();


			$sha_password = hash("sha512",rand(11111,99999));
			$password = password_hash($sha_password, PASSWORD_DEFAULT);
			$role = "p_admin";
			if (preg_match("/^[^@]+/", $email, $matches)) {
		        $username = ucwords(str_replace(['.', '_'], ' ', $matches[0]));
		    }
		    else
		    {
		    	$username = "";
		    }
			$stmt1 = $this->conn->prepare("INSERT INTO tbl_user (username, email, password, role, user_information_id) VALUES (:username, :email, :password, :role, :user_information_id);");
			$stmt1->bindparam(":username",$username);
			$stmt1->bindparam(":email",$email);
			$stmt1->bindparam(":password",$password);
			$stmt1->bindparam(":role",$role);
			$stmt1->bindparam(":user_information_id",$pa_id);
			$stmt1->execute();


			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function get_user_by_Email($email)
	{
		try 
		{
			$stmt  = $this->conn->prepare("SELECT *FROM tbl_user WHERE email = :email");
			$stmt->bindparam(":email",$email);
			$stmt->execute();
			$user = array();
			if($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[0] = $accountrow['user_information_id'];
			}
			return $user;
		} 
		catch (Exception $ex) {
			echo $ex->getMessage();
			
		}
	}
	
	function get_user_by_pID($pa_id)
	{
		try 
		{
			$stmt  = $this->conn->prepare("SELECT *FROM tbl_provider_admin WHERE pa_id = :pa_id");
			$stmt->bindparam(":pa_id",$pa_id);
			$stmt->execute();
			$user = array();
			if($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[0] = $accountrow['email'];
				$user[1] = $accountrow['first_name'];
				$user[2] = $accountrow['last_name'];
				$user[3] = $accountrow['profile_picture'];
			}
			return $user;
		} 
		catch (Exception $ex) {
			echo $ex->getMessage();
			
		}
	}

	function get_organization_by_user($user_id)
	{
		try 
		{
			$stmt  = $this->conn->prepare("SELECT *FROM tbl_user,tbl_seeker_manager,tbl_service_seeker WHERE tbl_user.user_information_id = tbl_seeker_manager.manager_id AND tbl_service_seeker.seeker_id = tbl_seeker_manager.seeker AND  tbl_user.user_id = :user_id");
			$stmt->bindparam(":user_id",$user_id);
			$stmt->execute();
			$user = array();
			if($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[0] = $accountrow['seeker_id'];
				$user[1] = $accountrow['seeker_name'];
			}
			return $user;
		} 
		catch (Exception $ex) {
			echo $ex->getMessage();
			
		}
	}

	function get_proformas()
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM tbl_proforma,tbl_service_seeker,tbl_category WHERE tbl_proforma.organization = tbl_service_seeker.seeker_id AND tbl_category.category_id = tbl_proforma.category ;");
			$stmt->execute();
			$places_array = array();
			$i = 0;
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$places_array[] = array(
		
					'proforma_id' => $accountrow['proforma_id'],
					'proforma_name' => $accountrow['proforma_name'],
					'seeker_name' => $accountrow['seeker_name'],
					'category_name' => $accountrow['category_name'],
					'items'=>$this->get_proforma_items_array($accountrow['proforma_id'])
					
				);
			}
			return $places_array;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function add_proforma_item($item_name, $quantity, $unit,$description,$proforma)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO tbl_proforma_items (item_name, quantity, unit, description, proforma) VALUES (:item_name, :quantity, :unit, :description, :proforma);");
			$stmt->bindparam(":item_name",$item_name);
			$stmt->bindparam(":quantity",$quantity);
			$stmt->bindparam(":unit",$unit);
			$stmt->bindparam(":description",$description);
			$stmt->bindparam(":proforma",$proforma);
			$stmt->execute();
			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function get_proforma_items_array($proforma)
	{
		try 
		{
			$stmt  = $this->conn->prepare("SELECT *FROM tbl_proforma_items WHERE proforma = :proforma");
			$stmt->bindparam(":proforma",$proforma);
			$stmt->execute();
			$user = array();
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[] = array(
		
					'item_id' => $accountrow['item_id'],
					'item_name' => $accountrow['item_name'],
					'quantity' => $accountrow['quantity'],
					'unit' => $accountrow['unit'],
					'description'=>$accountrow['description']
					
				);
			}
			return $user;
		} 
		catch (Exception $ex) {
			echo $ex->getMessage();
			
		}
	}
	function get_proforma_items($proforma)
	{
		try 
		{
			$stmt  = $this->conn->prepare("SELECT *FROM tbl_proforma_items WHERE proforma = :proforma");
			$stmt->bindparam(":proforma",$proforma);
			$stmt->execute();
			$user = array();
			$i=0;
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[$i][0] = $accountrow['item_id'];
				$user[$i][1] = $accountrow['item_name'];
				$user[$i][2] = $accountrow['quantity'];
				$user[$i][3] = $accountrow['unit'];
				$user[$i][4] = $accountrow['description'];
				$i++;
			}
			return $user;
		} 
		catch (Exception $ex) {
			echo $ex->getMessage();
			
		}
	}

	function get_proforma_by_org($organization)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM tbl_proforma WHERE organization = :organization;");
			$stmt->bindparam(":organization",$organization);
			$stmt->execute();
			$user = array();
			$i = 0;
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[$i][0] = $accountrow['proforma_id'];
				$user[$i][1] = $accountrow['proforma_name'];
				$user[$i][2] = $accountrow['created_on'];
				$user[$i][3] = $accountrow['status'];
				$i++;
			}
			return $user;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function add_team_to_org($first_name, $last_name, $email, $phone, $position, $organization)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO tbl_team (first_name, last_name, email, phone, position, organization) VALUES (:first_name, :last_name, :email, :phone, :position, :organization);");
			$stmt->bindparam(":first_name",$first_name);
			$stmt->bindparam(":last_name",$last_name);
			$stmt->bindparam(":email",$email);
			$stmt->bindparam(":phone",$phone);
			$stmt->bindparam(":position",$position);
			$stmt->bindparam(":organization",$organization);
			$stmt->execute();
			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	
	}

	function get_org_team($organization)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM tbl_team WHERE organization = :organization;");
			$stmt->bindparam(":organization",$organization);
			$stmt->execute();
			$user = array();
			$i = 0;
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[$i][0] = $accountrow['team_id'];
				$user[$i][1] = $accountrow['first_name'];
				$user[$i][2] = $accountrow['last_name'];
				$user[$i][3] = $accountrow['email'];
				$user[$i][4] = $accountrow['phone'];
				$user[$i][5] = $accountrow['position'];
				$i++;
			}
			return $user;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function add_team_to_purchase($member_id,$proforma)
	{
		try
		{
			$stmt = $this->conn->prepare("INSERT INTO proforma_team (proforma, member_id) VALUES (:proforma, :member_id);");
			$stmt->bindparam(":proforma",$proforma);
			$stmt->bindparam(":member_id",$member_id);
			$stmt->execute();
			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}

	function get_proforma_team($proforma)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM tbl_team,proforma_team WHERE proforma_team.member_id = tbl_team.team_id AND proforma_team.proforma = :proforma");
			$stmt->bindparam(":proforma",$proforma);
			$stmt->execute();
			$user = array();
			$i = 0;
			while($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				$user[$i][0] = $accountrow['pt_id'];
				$user[$i][1] = $accountrow['first_name'];
				$user[$i][2] = $accountrow['last_name'];
				$user[$i][3] = $accountrow['email'];
				$user[$i][4] = $accountrow['phone'];
				$user[$i][5] = $accountrow['position'];
				$i++;
			}
			return $user;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function is_team_in_proforma($member_id,$proforma)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM proforma_team WHERE member_id = :member_id AND proforma = :proforma");
			$stmt->bindparam(":member_id",$member_id);
			$stmt->bindparam(":proforma",$proforma);
			$stmt->execute();
			if($accountrow = $stmt->fetch(PDO::FETCH_ASSOC))
			{
				return true;
			}
			
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function get_company_by_user($manager)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT *FROM tbl_vendor WHERE manager = :manager");
			$stmt->bindparam(":manager",$manager);
			$stmt->execute();
			return $stmt->fetchAll(PDO::FETCH_ASSOC);
			
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
		}
	}

	function update_company($manager,$organization_name,$tin_number,$phone_number)
	{
		try
		{
			$stmt = $this->conn->prepare("UPDATE tbl_vendor SET organization_name = :organization_name, tin_number = :tin_number, phone_number = :phone_number WHERE manager = :manager;");
			$stmt->bindparam(":manager",$manager);
			$stmt->bindparam(":organization_name",$organization_name);
			$stmt->bindparam(":tin_number",$tin_number);
			$stmt->bindparam(":phone_number",$phone_number);
			$stmt->execute();
			return true;
		}
		catch(PDOException $ex)
		{
			echo $ex->getMessage();
			return false;
		}
	}
}
?>
