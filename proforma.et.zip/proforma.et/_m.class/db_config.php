<?php
class Database
{   
    private $host = "localhost";
    // private $db_name = "adwadilc_segonsurvey";
    // private $username = "adwadilc_segonsurveyuser";
    // private $password = "=mQ+l2r8D7^~";

    private $db_name = "proforma.et.db";
    private $username = "root";
    private $password = "";
    public $conn;
     
    public function dbConnection()
	{
     
	    $this->conn = null;    
        try
		{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
        }
		catch(PDOException $exception)
		{
            echo "Connection error: " . $exception->getMessage();
        }
         
        return $this->conn;
    }
}
?>