<?php
include_once 'include/db_connect.php';
include_once 'include/functions.php';
sec_session_start();
?>
<?php if (login_check($mysqli) == true) : ?>
<?php
include_once '_m.class/cl_queries.php';
$q = new CL_QUERIES();
$user_id = $_SESSION['user_id'];
$organization = $q->get_organization_by_user($user_id);
$proforma = $_GET['proforma_id'];
if(isset($_POST['item_name']))
{
  $item_name = $_POST['item_name'];
  $quantity = $_POST['quantity'];
  $unit = $_POST['unit'];
  $description  = $_POST['description'];
  
  if($q->add_proforma_item($item_name, $quantity, $unit,$description,$proforma))
  {
      header("location:proforma_items.php?proforma_id=".$proforma);
  }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
  if (!empty($_POST['team']))
  {
    $checkedteams = $_POST['team'];
    foreach ($checkedteams as $team)
    {
      $q->add_team_to_purchase($team,$proforma);
      echo $team.'-'.$proforma;
    }
    header("location:proforma_items.php?proforma_id=".$proforma);
  }
    
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Home | Proforma.et</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/select2/select2.min.css">
  <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/horizontal-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_horizontal-navbar.html -->
    <div class="horizontal-menu">

      <?php
      include('includes/top_nav.php');
      include('includes/bottom_nav.php');
      ?>
      

      

    </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">

        <div class="content-wrapper">

          <div class="d-sm-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
              <ul class="nav nav-tabs home-tab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active pl-2 pl-lg-0" id="Dashboards-tab" data-toggle="tab" href="#items" role="tab" aria-controls="Dashboards-1" aria-selected="true">1. Items</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="Apps-tab" data-toggle="tab" href="#team" role="tab" aria-selected="false">2. Purchase Team</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="Pages-tab" data-toggle="tab" href="#misc" role="tab" aria-selected="false">3. Misclaneous</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="Features-tab" data-toggle="tab" href="#publish" role="tab" aria-selected="false">4. Publish</a>
                  </li>
                </ul>
              </div>
          </div>
          <div class="tab-content tab-content-vertical">
            <div class="tab-pane fade show active" id="items" role="tabpanel" aria-labelledby="home-tab-vertical">
              <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Proforma Items</h4>
                        <p class="card-description">
                          Add your items here
                        </p>
                        <form class="forms-sample" method="post">
                          <div class="row">
                            <div class="col-12">
                              <div class="form-group">
                                <label for="exampleInputName1">Item Name</label>
                                <input type="text" class="form-control" name="item_name" placeholder="Name" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Quantity</label>
                                <input type="text" class="form-control" name="quantity" placeholder="Quantity" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputPassword4">Unit</label>
                                <select class="form-control" name="unit" required>
                                  <option disabled selected></option>
                                  <option>Unit</option>
                                  <option>Meter</option>
                                  <option>Killo</option>
                                  <option>Litter</option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="exampleTextarea1">Description</label>
                            <textarea class="form-control" name="description" rows="4" required></textarea>
                          </div>
                          <div class="form-group">
                            <div class="form-check">
                              <label class="form-check-label">
                                <input type="checkbox" class="form-check-input">
                                Sample is needed 
                              <i class="input-helper"></i></label>
                              <span>(Optional if the vendor has to submit sample of product)</span>
                            </div>
                          </div>
                          <button type="submit" class="btn btn-primary mr-2">Add</button>
                          
                        </form>

                      </div>
                    </div>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Your Items</h4>
                      <p class="card-description">
                        You can add as much as you want.
                      </p>
                      <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Item.</th>
                              <th>Quantity</th>
                              <th>Unit</th>
                              <th>Description</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $proforma_items = $q->get_proforma_items($proforma);
                            for($i=0;$i<count($proforma_items);$i++)
                            {
                              ?>
                              <tr>
                                <td><?php echo $i+1;?></td>
                                <td><?php echo $proforma_items[$i][1]; ?></td>
                                <td><?php echo $proforma_items[$i][2]; ?></td>
                                <td><?php echo $proforma_items[$i][3]; ?></td>
                                <td><?php echo $proforma_items[$i][4]; ?></td>
                                <td>
                                  <div class="dropdown arrow-none d-lg-block d-none">
                                    <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" id="profileDropdown5" aria-expanded="false">
                                        <i class="mdi mdi-dots-horizontal"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-left custom-drop-down" aria-labelledby="profileDropdown5">
                                      <a class="dropdown-item" href="">
                                        <i class="mdi mdi-pencil-box-outline"></i> Edit
                                      </a>
                                      <a class="dropdown-item" href="">
                                        <i class="mdi mdi-delete"></i> Delete
                                      </a>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <?php
                            }
                            ?>
                            
                          </tbody>
                        </table>

                      </div>

                    </div>

                  </div>

                </div>
              </div>

            </div>
            <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="profile-tab-vertical">
              <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body"><a href="team_manager.php" class="btn btn-md btn-primary mr-2" style="float:right;">Open Team Manager</a>
                        <h4 class="card-title">Purchase team</h4>

                        <p class="card-description">
                          Additional information before publishing.
                        </p>
                        <hr>
                        <form class="forms-sample" method="post">
                          <div class="table-responsive">
                            <table class="table table-striped table-hover">
                              <thead>
                                <tr>
                                  <th>
                                    Name
                                  </th>
                                  <th>
                                    Email
                                  </th>
                                  <th>
                                    Phone
                                  </th>
                                  <th>
                                    Position
                                  </th>
                                  
                                </tr>
                              </thead>
                              <tbody>
                                <?php
                                
                                $team = $q->get_org_team($organization[0]);
                                $j = 0;
                                for($i=0;$i<count($team);$i++)
                                {
                                  if ($q->is_team_in_proforma($team[$i][0],$proforma))
                                  {

                                  }
                                  else
                                  {
                                    $j++;
                                    ?>
                                    <tr>
                                      <td class="py-1">
                                        <div class="form-check">
                                          <label class="form-check-label">
                                            <input type="checkbox" name="team[]" value="<?php echo $team[$i][0]; ?>" class="form-check-input">
                                            <?php echo $team[$i][1].' '.$team[$i][2]; ?>
                                          <i class="input-helper"></i></label>
                                        </div>
                                      </td>
                                      <td><?php echo $team[$i][3]; ?></td>
                                      <td><?php echo $team[$i][4]; ?></td>
                                      <td><?php echo $team[$i][5]; ?></td>
                                    </tr>
                                    <?php
                                  }
                                  ?>
                                  
                                  <?php
                                }
                                ?>
                              </tbody>
                            </table>
                          </div>
                          
                          <?php
                          if($j==0)
                          {
                            ?>
                            <div class="alert alert-warning" role="alert">
                              You have added everyone to the proforma.
                            </div>
                            <?php
                          }
                          else
                          {
                            ?>
                            <hr>
                            <button type="submit" class="btn btn-primary mr-2">Add to Proforma</button>
                            <?php
                          }
                          ?>
                          
                          
                        </form>

                      </div>
                    </div>
                </div>
              </div>

              <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Your team</h4>

                        <p class="card-description">
                          Teams that you have added for this proforma.
                        </p>
                          <?php
                          $proforma_team = $q->get_proforma_team($proforma);
                          if(count($proforma_team)>0)
                          {
                            ?>
                            <div class="table-responsive">
                              <table class="table table-striped">
                                <thead>
                                  <tr>
                                    <th>
                                      Name
                                    </th>
                                    <th>
                                      Email
                                    </th>
                                    <th>
                                      Phone
                                    </th>
                                    <th>
                                      Position
                                    </th>
                                    <th>
                                      Action
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php
                                  
                                  for($i=0;$i<count($proforma_team);$i++)
                                  {
                                    ?>
                                    <tr>
                                      <td><?php echo $proforma_team[$i][1].' '.$team[$i][2]; ?></td>
                                      <td><?php echo $proforma_team[$i][3]; ?></td>
                                      <td><?php echo $proforma_team[$i][4]; ?></td>
                                      <td><?php echo $proforma_team[$i][5]; ?></td>
                                      <td>
                                        <a class="btn btn-outline-danger btn-icon-text">
                                        <i class="mdi mdi-delete btn-icon-prepend"></i>                                                    
                                        Remove
                                      </button>
                                      </td>
                                    </tr>
                                    <?php
                                  }
                                  ?>
                                </tbody>
                              </table>
                            </div>
                            <?php
                          }
                          else
                          {
                            ?>
                            <div class="alert alert-info" role="alert">
                              There are not team in this proforma, please add.
                            </div>
                            
                            <?php
                          }
                          ?>
                          

                      </div>
                    </div>
                </div>
              </div>


            </div>
            <div class="tab-pane fade" id="misc" role="tabpanel" aria-labelledby="contact-tab-vertical">
              <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Miscellaneous Information</h4>
                        <p class="card-description">
                          Additional information before publishing.
                        </p>
                        <form class="forms-sample" method="post">
                          <div class="row">
                            
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">End of submission</label>
                                <input type="date" class="form-control" name="quantity" placeholder="Quantity" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Opening Date</label>
                                <input type="date" class="form-control" name="quantity" placeholder="Quantity" required>
                              </div>
                            </div>
                            
                          </div>
                          <button type="submit" class="btn btn-primary mr-2">Save</button>
                          
                        </form>

                      </div>
                    </div>
                </div>
              </div>

            </div>
          </div>
        </div>



         
            

        <?php
        include('includes/footer.php');
        ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/todolist.js"></script>

  <script src="vendors/select2/select2.min.js"></script>
 
  <script src="js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
<?php else : ?>
    <p>
        <span class="error">You are not authorized to access this page.</span> Please <a href="login.php">login</a>.
    </p>
<?php endif; ?>