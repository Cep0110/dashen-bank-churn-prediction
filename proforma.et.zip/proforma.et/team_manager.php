<?php
include_once 'include/db_connect.php';
include_once 'include/functions.php';
sec_session_start();
?>
<?php if (login_check($mysqli) == true) : ?>
<?php
include_once '_m.class/cl_queries.php';
$q = new CL_QUERIES();
$user_id = $_SESSION['user_id'];
$organization = $q->get_organization_by_user($user_id);

if(isset($_POST['fname']))
{
  $first_name = $_POST['fname'];
  $middle_name = $_POST['mname'];
  $email = $_POST['email'];
  $phone  = $_POST['phone'];
  $position  = $_POST['position'];
  
  if($q->add_team_to_org($first_name, $middle_name, $email, $phone, $position, $organization[0]))
  {
      header("location:team_manager.php");
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Team Manager</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/select2/select2.min.css">
  <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/horizontal-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_horizontal-navbar.html -->
    <div class="horizontal-menu">

      <?php
      include('includes/top_nav.php');
      include('includes/bottom_nav.php');
      ?>
      

      

    </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">

        <div class="content-wrapper">

          <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Team Manager</h4>
                        <p class="card-description">
                          Add your items here
                        </p>
                        <form class="forms-sample" method="post">
                          <div class="row">
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">First Name</label>
                                <input type="text" class="form-control" name="fname" placeholder="First Name" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Middle Name</label>
                                <input type="text" class="form-control" name="mname" placeholder="Middle Name" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Email" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Phone</label>
                                <input type="text" class="form-control" name="phone" placeholder="Phone" required>
                              </div>
                            </div>
                            <div class="col-6">
                              <div class="form-group">
                                <label for="exampleInputEmail3">Position</label>
                                <input type="text" class="form-control" name="position" placeholder="Position" required>
                              </div>
                            </div>

                          </div>
                          <button type="submit" class="btn btn-primary mr-2">Add</button>
                          
                        </form>

                      </div>
                    </div>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Your Items</h4>
                      <p class="card-description">
                        You can add as much as you want.
                      </p>
                      <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Phone</th>
                              <th>Position</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $team = $q->get_org_team($organization[0]);
                            for($i=0;$i<count($team);$i++)
                            {
                              ?>
                              <tr>
                                <td><?php echo $i+1;?></td>
                                <td><?php echo $team[$i][1].' '.$team[$i][2]; ?></td>
                                <td><?php echo $team[$i][3]; ?></td>
                                <td><?php echo $team[$i][4]; ?></td>
                                <td><?php echo $team[$i][5]; ?></td>
                                <td>
                                  <div class="dropdown arrow-none d-lg-block d-none">
                                    <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" id="profileDropdown5" aria-expanded="false">
                                        <i class="mdi mdi-dots-horizontal"></i>
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-left custom-drop-down" aria-labelledby="profileDropdown5">
                                      <a class="dropdown-item" href="">
                                        <i class="mdi mdi-pencil-box-outline"></i> Edit
                                      </a>
                                      <a class="dropdown-item" href="">
                                        <i class="mdi mdi-delete"></i> Delete
                                      </a>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <?php
                            }
                            ?>
                            
                          </tbody>
                        </table>

                      </div>

                    </div>

                  </div>

                </div>
              </div>

          
          
        </div>



         
            

        <?php
        include('includes/footer.php');
        ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/todolist.js"></script>

  <script src="vendors/select2/select2.min.js"></script>
 
  <script src="js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
<?php else : ?>
    <p>
        <span class="error">You are not authorized to access this page.</span> Please <a href="login.php">login</a>.
    </p>
<?php endif; ?>