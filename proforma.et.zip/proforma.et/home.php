<?php
include_once 'include/db_connect.php';
include_once 'include/functions.php';
sec_session_start();
?>
<?php if (login_check($mysqli) == true) : ?>
<?php
include_once '_m.class/cl_queries.php';
$q = new CL_QUERIES();
$user_id = $_SESSION['user_id'];
$organization = $q->get_organization_by_user($user_id);
$organization_id = $organization[0];
if(isset($_POST['pname']))
{
  $proforma_name = $_POST['pname'];
  $category = $_POST['category'];
  $proforma_id = md5(uniqid(mt_rand(),true));
  if($q->create_proforma($proforma_id, $proforma_name, $category, $organization_id))
  {
      header("location:proforma_items.php?proforma_id=".$proforma_id);
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Home | Proforma.et</title>
  <!-- base:css -->
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/select2/select2.min.css">
  <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/horizontal-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_horizontal-navbar.html -->
    <div class="horizontal-menu">

      <?php
      include('includes/top_nav.php');
      include('includes/bottom_nav.php');
      ?>
      

      

    </div>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper p-0 pt-4">

          <div class="welcome-message">
            <div class="d-lg-flex justify-content-between align-items-center">
              <div class="pr-5 image-border"><img src="images/dashboard/welcome.png" alt="welcome"></div>
              <div class="pl-4">
                <h2 class="text-white font-weight-bold mb-3">Welcome to Profroma.et</h2>
                <p class="pb-0 mb-1">Congratulations! Your account has been setup and you are ready to configure your account now.</p>
                <p>Please confirm our email before we proceed any further</p>
              </div>
              <div class="pl-4">
                <button type="button" class="btn btn-primary" id="skip-mesages">Skip</button>
                <button type="button" class="btn btn-success ml-lg-0 ml-xl-2 ml-2 ml-l mt-lg-2 mt-xl-0">Confirm Email</button>
              </div>
            </div>
          </div>

         
          <div class="tab-content home-tab-content">
            <div class="tab-pane fade show active" id="Dashboards-1" role="tabpanel" aria-labelledby="Dashboards-tab">
              <div class="d-sm-flex justify-content-between align-items-center my-3">
                <h3 class="text-dark font-weight-medium">Sales dashboard overview</h3>
                <div class="link-btn-group d-flex justify-content-start align-items-start">
                  <button type="button" class="btn btn-link text-dark py-0 pl-0">Add info</button>
                  <button type="button" class="btn btn-link text-dark py-0">Get updated by email</button>
                  <button type="button" class="btn btn-link text-dark py-0">See more</button>
                </div>
              </div>
              <div class="row">
                <div class="col-xl-4 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center">
                          <h4 class="card-title mb-0">Purchasing Activity</h4>
                          <button type="button" class="btn btn-link btn-md text-light p-0">14 Jan 2023</button>
                      </div>
                      <h2 class="text-dark font-weight-bold my-3">234</h2>
                      <canvas id="account-retension"></canvas>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 grid-margin stretch-card">
                  <div class="card">
                      <div class="card-body">
                          <div class="custom-fieldset mb-4">
                            <div class="clearfix">
                              <label class="">Suppliers</label>
                            </div>
                            <div class="d-lg-flex align-items-center text-dark">
                              <i class="mdi mdi-inbox-arrow-up mr-3 mdi-36px animate-icon"></i>
                                <div>
                                  <h2 class="mb-0 mt-2 mt-sm-0">1245</h2>
                                  <div class="text-light d-flex align-items-center"><span class="text-success mr-2 font-weight-medium d-flex align-items-center"><i class="mdi mdi-menu-up mdi-18px"></i>+4531</span>avg. sales per day</div>
                                </div>
                            </div>
                          </div>
                          <div class="custom-fieldset mt-3">
                            <div class="clearfix">
                              <label>Your Proformas so far</label>
                            </div>
                            <div class="d-lg-flex align-items-center text-dark">
                              <i class="mdi mdi-cart-outline mr-3 mdi-36px animate-icon"></i>
                                <div>
                                  <h2 class="mb-0 mt-2 mt-sm-0">34</h2>
                                  <div class="text-light d-flex align-items-center"><span class="text-danger mr-2 font-weight-medium d-flex align-items-center"><i class="mdi mdi-menu-down mdi-18px"></i>-231.33</span>avg. sales per day</div>
                                </div>
                            </div>
                          </div>
                      </div>
                  </div>
                </div>
                <div class="col-xl-4 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-md-6">
                          <p class="text-dark font-weight-medium">Active Proformas</p>
                          <h1 class="text-dark  mt-3">7</h1>
                          <p class="text-dark text-small"><span class="circle-arrow"><i class="mdi mdi-arrow-top-right"></i></span>Avg. Sales per Day</p> 
                        </div>
                        <div class="col-md-6">
                            <canvas id="earnings" class=" mt-3"></canvas> 
                        </div>
                      </div>
                      <div class="row mt-4">
                          <div class="col-md-6 mb-4 mb-sm-0">
                            <p class="text-dark">Today so far</p>
                            <h2 class="text-dark  mt-2">4</h2>
                            <div class="text-light d-flex align-items-center text-extra-small"><span class="text-success mr-2 font-weight-medium d-flex align-items-center"><i class="mdi mdi-menu-up  mdi-18px"></i>+43.54%</span>Last week</div>
                          </div>
                          <div class="col-md-6">
                            <p class="text-dark">Total Submissions</p>
                            <h2 class="text-dark  mt-2">45</h2>
                            <div class="text-light d-flex align-items-center text-extra-small"><span class="text-success mr-2 font-weight-medium d-flex align-items-center"><i class="mdi mdi-menu-up  mdi-18px"></i>0.7% </span>Last month</div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
             
             <div class="modal fade" id="exampleModal-4" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="ModalLabel">New Proforma</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <form method="post">
                      <div class="modal-body">
                        <div class="form-group">
                          <label for="recipient-name" class="col-form-label">Let's give it a name:</label>
                          <input type="text" class="form-control" id="recipient-name" placeholder="Computers for <?php echo $organization[1];?> " name="pname">
                        </div>
                        <div class="form-group">
                          <label for="message-text" class="col-form-label">Category:</label>
                          <br>
                          <select class="form-control js-example-basic-single w-100" style="width:100%" name="category">
                            <option value="1">Computer</option>
                            <option value="2">Computer Accessories</option>
                            <option value="3">Stationaries</option>
                            <option value="4">Cleaning Materials</option>
                            <option value="5">Furnitures</option>
                          </select>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button class="btn btn-success">Continue</button>
                        <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
                      </div>
                    </form>

                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Your Proformas</h4>
                      <p class="card-description">
                        You can add as much as you want.
                      </p>
                      <div class="table-responsive">
                        <table class="table">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Proforma</th>
                              <th>Date Created</th>
                              <th>Status</th>
                              <th>Submission</th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                            $proforma = $q->get_proforma_by_org($organization_id);
                            for($i=0;$i<count($proforma);$i++)
                            {
                              ?>
                              <tr>
                                <td><?php echo $i+1;?></td>
                                <td><a href="proforma_items.php?proforma_id=<?php echo $proforma[$i][0];?>"><?php echo $proforma[$i][1]; ?></a></td>
                                <td><?php echo $proforma[$i][2]; ?></td>
                                <td>
                                  <?php
                                  if($proforma[$i][3]=="Published")
                                  {
                                    ?>
                                    <label class="badge badge-success">Published</label>
                                    <?php
                                  }
                                  if($proforma[$i][3]=="Draft")
                                  {
                                    ?>
                                    <label class="badge badge-info">Draft</label>
                                    <?php
                                  }
                                  ?>
                                </td>
                                
                                <td>0</td>
                                <td>
                                  <a href="" style="color: green; font-size: 22px;"><i class="mdi mdi-tooltip-edit"></i></a>
                                  <a href="" style="color: red; font-size: 24px;"><i class="mdi mdi-delete-forever"></i></a>
                                </td>
                              </tr>
                              <?php
                            }
                            ?>
                            
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

             
            </div>
              <div class="row"> 
                <div class="col-md-12 stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-sm-flex justify-content-between align-items-center">
                        <h4 class="card-title">Purchase Team</h4>
                        <div class="d-flex">
                            <button type="button" class="btn btn-outline-primary btn-icon-text my-2 my-lg-0">
                              <i class="mdi mdi-printer text-extra-small btn-icon-prepend"></i>
                              Print
                            </button>
                          <button type="button" class="btn btn-outline-primary btn-icon-text ml-3  my-2 my-lg-0">
                            <i class="mdi mdi-email-outline text-extra-small btn-icon-prepend"></i>
                            Email
                          </button>
                          <button type="button" class="btn btn-primary ml-3  my-2 my-lg-0">Generate Report</button>
                        </div>
                      </div>
                      <div class="mb-4">
                        <span class="pr-2">Sales</span><span class="pr-2"><i class="mdi mdi-chevron-right"></i></span><span>Purchase history</span>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                            <div class="table-responsive">
                              <table class="table">
                                <thead>
                                  <tr>
                                    <th class="pt-1 pl-0">
                                      Assigned
                                    </th>
                                    <th class="pt-1">
                                      Product
                                    </th>
                                    <th class="pt-1">
                                      Priority
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td class="py-1 pl-0">
                                      <div class="d-flex align-items-center">
                                        <img src="images/faces/face1.jpg" alt="profile">
                                        <div class="ml-3">
                                          <p class="mb-0">Sophia Brown</p>
                                          <p class="mb-0 text-muted text-small">Product Designer</p>
                                        </div>
                                      </div>
                                    </td>
                                    <td>
                                      Web App
                                    </td>
                                    <td>
                                      <label class="badge badge-success">Low</label>
                                    </td>
                                  </tr>
                                
                                </tbody>
                              </table>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php
        include('includes/footer.php');
        ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- base:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/template.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/todolist.js"></script>

  <script src="vendors/select2/select2.min.js"></script>
 
  <script src="js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
<?php else : ?>
    <p>
        <span class="error">You are not authorized to access this page.</span> Please <a href="login.php">login</a>.
    </p>
<?php endif; ?>