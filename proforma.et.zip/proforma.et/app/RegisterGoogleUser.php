<?php
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();
if(isset($_POST['Email']))
{
	$givenName = $_POST['givenName'];
	$FamilyName = $_POST['FamilyName'];
	$email = $_POST['Email'];
	$personPhoto = $_POST['personPhoto'];

	$user = $q->get_user_by_Email($email);
	if(count($user)>0)
	{
		$result = "true";
		$pa_id = $user[0];
		echo json_encode(['result'=>$result,'pa_id'=>$pa_id,'org_config'=>'0']);
	}
	else
	{
		$pa_id = hash('sha256', uniqid(bin2hex(random_bytes(8)), true));
		if($q->register_pa_with_Google($givenName,$FamilyName,$email,$pa_id,$personPhoto))
		{
			$result = "true";
	    }
	    else
	    {
	    	$result = "false";
	    }
	    echo json_encode(['result'=>$result,'pa_id'=>$pa_id,'org_config'=>'1']);
	}

}
else
{
	$result = "Invalid request";
	echo json_encode(['result'=>$result]);
}