<?php
Header('Content-Type: application/json; charset=UTF-8');
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();

$proformas = $q->get_proformas();
echo json_encode(['status'=>'success','proformas'=>$proformas],JSON_PRETTY_PRINT );
