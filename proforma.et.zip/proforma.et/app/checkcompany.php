<?php
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();
if(isset($_POST['user_id']))
{
	$status = "ok";
	$user_id = $_POST['user_id'];
	$company = $q->get_company_by_user($user_id);
	if(count($company)>0)
	{
		if($company[0]['organization_name']==""||$company[0]['tin_number']==""||$company[0]['phone_number']=="")
		{
			$result_code = "2";//incomplete company information
		}
		else
		{
			$result_code = "1";//company information is complete
		}	
		echo json_encode(['status'=>$status,'result'=>$result_code]);
	}
	else
	{
		$status = "ok";
		$result_code = "3";//No Company
		echo json_encode(['status'=>$status,'result'=>$result_code]);
	}
}
else
{
	$result = "Invalid request";
	echo json_encode(['result'=>$result]);
}