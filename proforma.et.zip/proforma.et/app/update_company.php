<?php
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();
if(isset($_POST['user_id'],$_POST['company_name'],$_POST['tin_number'],$_POST['phone_number']))
{
	$status = "ok";
	$result_code = "success";
	$user_id = $_POST['user_id'];
	$company_name = $_POST['company_name'];
	$tin_number = $_POST['tin_number'];
	$phone_number = $_POST['phone_number'];
	
	if($q->update_company($user_id,$company_name,$tin_number,$phone_number))
	{
		echo json_encode(['status'=>$status,'result'=>$result_code]);
	}
	else
	{
		$status = "ok";
		$result_code = "Failed to update company information";
		echo json_encode(['status'=>$status,'result'=>$result_code]);
	}
}
else
{
	$status = "error";
	$result = "Invalid request";
	echo json_encode(['status'=>$result,'result'=>$result]);
}