<?php
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();
if(isset($_POST['email']))
{
	$email = $_POST['email'];
	$password = $_POST['password'];
	$pa_id = hash('sha256', uniqid(bin2hex(random_bytes(8)), true));
	if($q->register_pa($email,$password,$pa_id))
	{
		$result = "true";
    }
    else
    {
    	$result = "false";
    }
	echo json_encode(['result'=>$result,'pa_id'=>$pa_id]);
}