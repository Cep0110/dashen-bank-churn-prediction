<?php
include_once '../_m.class/cl_queries.php';
$q = new CL_QUERIES();
if(isset($_POST['pID']))
{
	$pID = $_POST['pID'];
	$user = $q->get_user_by_pID($pID);
	if(count($user)>0)
	{
		$result = "true";
		echo json_encode(['result'=>$result,'user'=>$user]);
	}
}
else
{
	$result = "Invalid request";
	echo json_encode(['result'=>$result]);
}